package exercicio_2;

public class Medico extends Pessoa {
	private String CRM,Especialidade;
	public Medico(String nome,long CPF, long RG, Cidade cidade,long tel, String CRM, String Especialidade){
		super(nome,CPF,RG,cidade,tel);
		this.CRM = CRM;
		this.Especialidade = Especialidade;
	}
	public String toString(){
		String strMedico = super.toString() +  "CRM =" + CRM + ", Especialidade =" + Especialidade + "\n";
		return strMedico;
	}

}
