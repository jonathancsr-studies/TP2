package exercicio_2;

public class Especialidade {
	String descricao;
	
	public Especialidade(String descricao){
		this.descricao = descricao;
	}
	
	public String toString() {
		return "Especialidade =" + descricao;
	}
}
