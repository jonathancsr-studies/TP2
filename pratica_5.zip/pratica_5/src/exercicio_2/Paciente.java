package exercicio_2;

public class Paciente extends Pessoa{
	String convenio;
	public Paciente (String nome,long CPF, long RG, Cidade cidade,long tel, String convenio){
		super(nome,CPF,RG,cidade,tel);
		this.convenio = convenio;
	}
	
	public String toStrinf() {
		String strPaciente = super.toString() + ", convenio =" + convenio + "\n";
		return strPaciente;
	}	
	
	
	
}
