package exercicio_2;

public class Pessoa {
	private String nome;
	private long tel,CPF,RG;
	Cidade cidade;
	
	public Pessoa(String nome, long CPF, long RG, Cidade cidade, long tel){
		this.nome = nome;
		this.CPF = CPF;
		this.RG = RG;
		this.tel = tel;
		this.cidade = cidade;
	}
	public String toString() {
		return "Nome =" + nome +", CPF=" + CPF + ", RG =" + RG + ", Telefone =" + tel + cidade.toString();
	}
	
}
