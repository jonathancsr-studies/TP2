package exercicio_1;

public class ContaPoupanca extends Conta {
	private double rendimento;
	public ContaPoupanca(long num, double rendimento){
		super(num);
		this.rendimento = rendimento;		
	}
	public void atualizarRendimento(){
		saldo*= (rendimento + 1);
	}

}
