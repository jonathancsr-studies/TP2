package exercicio_1;

public class Conta {
	protected long numero;
	protected double saldo;
	public Conta(long num) {
		numero = num;
		saldo = 0;
	}
	public void depositar(double v){
		if (v>0)
			saldo = saldo + v;
		}
	public boolean sacar(double v){
		if( v>0 && ((saldo-v) >= 0) ){
			saldo = saldo - v;
			return true;
		}else
			return false;
	}
	public double getSaldo(){
		return saldo;
	}
	public long getNumero(){
		return numero;
	}
	public void setSaldo(double atualiza){
		saldo = atualiza;
	}
	public String toString(){
		return "Número: "+numero+" saldo: "+saldo;
	}
}