package exercicio_1;

public class Principal {
	public static void main (String[] args){
		ContaPoupanca conta1 = new ContaPoupanca(103,0.1);
		
		conta1.depositar(100);
		System.out.println(conta1);
		conta1.atualizarRendimento();
		System.out.println(conta1);
		
		
	}
}